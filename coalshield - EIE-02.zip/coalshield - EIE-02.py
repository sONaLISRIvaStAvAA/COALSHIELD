# -*- coding: utf-8 -*-

from flask import Flask, jsonify, render_template_string
import threading
import time
import board
import adafruit_dht
import RPi.GPIO as GPIO
import serial
import pynmea2

import Adafruit_BMP.BMP085 as BMP085
from mpu6050 import mpu6050
from max30102 import MAX30102
import hrcalc

app = Flask(__name__)

# ---------------- BUZZER ----------------
BUZZER = 18
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(BUZZER, GPIO.OUT, initial=GPIO.LOW)

# ---------------- SAFE INIT ----------------
try:
    dht = adafruit_dht.DHT11(board.D4)
except:
    dht = None

try:
    bmp = BMP085.BMP085(busnum=1)
except:
    bmp = None

try:
    mpu = mpu6050(0x68)
except:
    mpu = None

try:
    gps_serial = serial.Serial("/dev/serial0", baudrate=9600, timeout=1)
except:
    gps_serial = None

try:
    hr_sensor = MAX30102()
except:
    hr_sensor = None

# ---------------- DATA ----------------
latest_data = {
    "temperature": 0,
    "humidity": 0,
    "pressure": 0,
    "accel": 0,
    "heart_rate": 0,
    "latitude": 0,
    "longitude": 0,
    "alert": False
}

# ---------------- SENSOR LOOP ----------------
def sensor_loop():
    global latest_data

    while True:

        temp = hum = pressure = accel = heart_rate = lat = lon = 0
        fall_detected = False
        alert = False

        # -------- DHT --------
        try:
            if dht:
                temp = dht.temperature or 0
                hum = dht.humidity or 0
        except:
            pass

        # -------- BMP --------
        try:
            if bmp:
                pressure = bmp.read_pressure() / 100
        except:
            pass

        # -------- MPU --------
        try:
            if mpu:
                a = mpu.get_accel_data()

                ax = a.get('x', 0)
                ay = a.get('y', 0)
                az = a.get('z', 0)

                accel = round((ax**2 + ay**2 + az**2) ** 0.5, 2)

                if accel > 10 or accel < 3:
                    fall_detected = True

        except:
            accel = 0

        # -------- HEART --------
        try:
            if hr_sensor:
                red, ir = hr_sensor.read_sequential()
                hr, valid, _, _ = hrcalc.calc_hr_and_spo2(ir, red)
                if valid:
                    heart_rate = hr
        except:
            pass

        # -------- GPS --------
        
        lat = 0
        lon = 0

        try:

            data = gps_serial.readline().decode()

            if data.startswith('$GPGGA'):

                msg = pynmea2.parse(data)

                lat = msg.latitude
                lon = msg.longitude

        except:
            pass


        # -------- ALERT CONDITIONS --------
        if temp > 50 or temp < 20:
            alert = True

        if hum > 90:
            alert = True

        if pressure > 1000:
            alert = True

        if heart_rate > 100 or (heart_rate < 50 and heart_rate != 0):
            alert = True

        if fall_detected:
            alert = True

        # -------- BUZZER --------
        GPIO.output(BUZZER, GPIO.HIGH if alert else GPIO.LOW)

        latest_data.update({
            "temperature": temp,
            "humidity": hum,
            "pressure": pressure,
            "accel": accel,
            "heart_rate": heart_rate,
            "latitude": lat,
            "longitude": lon,
            "alert": alert
        })

        time.sleep(2)

# ---------------- THREAD ----------------
thread = threading.Thread(target=sensor_loop)
thread.daemon = True
thread.start()

# ---------------- UI ----------------
NAVBAR = """
<style>

body {
 font-family: Segoe UI;
 background: #0f172a;
 color: white;
 margin: 0;
}

.navbar {
 background: #020617;
 padding: 12px;
 text-align: center;
 font-size: 18px;
 font-weight: bold;
}

.title {
 text-align: center;
 padding-top: 15px;
}

.card-container {
 display: grid;
 grid-template-columns: repeat(auto-fit,minmax(220px,1fr));
 gap: 20px;
 padding: 20px;
}

.card {
 background: linear-gradient(145deg,#1e293b,#0f172a);
 padding: 25px;
 border-radius: 16px;
 text-align: center;
 cursor: pointer;
 font-size: 18px;
}

.alert-box{
 display:none;
 background:red;
 color:white;
 padding:15px;
 text-align:center;
 font-size:20px;
 font-weight:bold;
 animation:blink 1s infinite;
}

@keyframes blink {
 50% {opacity:0.4;}
}

iframe {
 width:100%;
 height:350px;
 border-radius:10px;
}

</style>

<div class="navbar">
Coalshield Smart Jacket
</div>
"""

HOME_PAGE = NAVBAR + """

<div id="alertBox" class="alert-box">
ALERT! Abnormal Condition Detected!
</div>

<div class="title">
<h1>Coalshield - The Ambient Smart Jacket</h1>
</div>

<div class="card-container">

<div class="card" onclick="openGraph('temperature')">
Temp: <span id="temp">--</span> C
</div>

<div class="card" onclick="openGraph('humidity')">
Humidity: <span id="hum">--</span> %
</div>

<div class="card" onclick="openGraph('pressure')">
Pressure: <span id="pres">--</span> hPa
</div>

<div class="card" onclick="openGraph('accel')">
Acceleration: <span id="accel">--</span>
</div>

<div class="card" onclick="openGraph('heart_rate')">
Heart Rate: <span id="heart">--</span> BPM
</div>

<div class="card" onclick="openGraph('latitude')">
Latitude: <span id="lat">--</span>
</div>

<div class="card" onclick="openGraph('longitude')">
Longitude: <span id="lon">--</span>
</div>

</div>

<iframe id="map"
src="https://maps.google.com/maps?q=0,0&z=15&output=embed">
</iframe>

<script>

function openGraph(param){
 window.location.href='/graph/'+param;
}

function updateData(){

fetch('/data')
.then(res=>res.json())
.then(data=>{

document.getElementById("temp").innerHTML=data.temperature;
document.getElementById("hum").innerHTML=data.humidity;
document.getElementById("pres").innerHTML=data.pressure;
document.getElementById("accel").innerHTML=data.accel;
document.getElementById("heart").innerHTML=data.heart_rate;
document.getElementById("lat").innerHTML=data.latitude;
document.getElementById("lon").innerHTML=data.longitude;

if(data.alert){
 document.getElementById("alertBox").style.display="block";
}
else{
 document.getElementById("alertBox").style.display="none";
}

document.getElementById("map").src=
"https://maps.google.com/maps?q="
+data.latitude+","+data.longitude+
"&z=15&output=embed";

});

}

setInterval(updateData,2000);

</script>
"""

# ---------------- GRAPH ROUTE ----------------
@app.route('/graph/<param>')
def graph(param):
    return render_template_string("""

<!DOCTYPE html>
<html>
<head>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>

body{
 margin:0;
 background:white;
 font-family:Segoe UI;
 text-align:center;
}

.chart-container{
 width:100%;
 height:80vh;
 padding:20px;
}

canvas{
 width:100% !important;
 height:100% !important;
}

button{
 margin-top:15px;
 padding:10px 20px;
 font-size:16px;
}

</style>

</head>

<body>

<h2>Live Graph - {{param}}</h2>

<button onclick="goBack()">Back</button>

<div class="chart-container">
<canvas id="chart"></canvas>
</div>

<script>

function goBack(){
 window.location.href="/";
}

let labels=[];
let values=[];

const ctx=document.getElementById('chart');

let chart=new Chart(ctx,{
 type:'line',
 data:{
  labels:labels,
  datasets:[{
   label:'{{param}}',
   data:values,
   borderColor:'blue',
   fill:false
  }]
 },
 options:{
  responsive:true,
  maintainAspectRatio:false
 }
});

function updateGraph(){

fetch('/data')
.then(r=>r.json())
.then(d=>{

labels.push(new Date().toLocaleTimeString());
values.push(d["{{param}}"]);

if(labels.length>20){
 labels.shift();
 values.shift();
}

chart.update();

});

}

setInterval(updateGraph,2000);

</script>

</body>
</html>

""", param=param)

# ---------------- ROUTES ----------------
@app.route('/')
def home():
    return render_template_string(HOME_PAGE)

@app.route('/data')
def data():
    return jsonify(latest_data)

# ---------------- MAIN ----------------
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)